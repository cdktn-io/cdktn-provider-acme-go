/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#account_key_algorithm Registration#account_key_algorithm}
    */
    readonly accountKeyAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#account_key_ecdsa_curve Registration#account_key_ecdsa_curve}
    */
    readonly accountKeyEcdsaCurve?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#account_key_pem Registration#account_key_pem}
    */
    readonly accountKeyPem?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#account_key_rsa_bits Registration#account_key_rsa_bits}
    */
    readonly accountKeyRsaBits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#email_address Registration#email_address}
    */
    readonly emailAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#id Registration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * external_account_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#external_account_binding Registration#external_account_binding}
    */
    readonly externalAccountBinding?: RegistrationExternalAccountBinding;
}
export interface RegistrationExternalAccountBinding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#hmac_base64 Registration#hmac_base64}
    */
    readonly hmacBase64: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#key_id Registration#key_id}
    */
    readonly keyId: string;
}
export declare function registrationExternalAccountBindingToTerraform(struct?: RegistrationExternalAccountBindingOutputReference | RegistrationExternalAccountBinding): any;
export declare function registrationExternalAccountBindingToHclTerraform(struct?: RegistrationExternalAccountBindingOutputReference | RegistrationExternalAccountBinding): any;
export declare class RegistrationExternalAccountBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RegistrationExternalAccountBinding | undefined;
    set internalValue(value: RegistrationExternalAccountBinding | undefined);
    private _hmacBase64?;
    get hmacBase64(): string;
    set hmacBase64(value: string);
    get hmacBase64Input(): string | undefined;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration acme_registration}
*/
export declare class Registration extends cdktn.TerraformResource {
    static readonly tfResourceType = "acme_registration";
    /**
    * Generates CDKTN code for importing a Registration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Registration to import
    * @param importFromId The id of the existing Registration that should be imported. Refer to the {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Registration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/vancluever/acme/2.48.2/docs/resources/registration acme_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RegistrationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: RegistrationConfig);
    private _accountKeyAlgorithm?;
    get accountKeyAlgorithm(): string;
    set accountKeyAlgorithm(value: string);
    resetAccountKeyAlgorithm(): void;
    get accountKeyAlgorithmInput(): string | undefined;
    private _accountKeyEcdsaCurve?;
    get accountKeyEcdsaCurve(): string;
    set accountKeyEcdsaCurve(value: string);
    resetAccountKeyEcdsaCurve(): void;
    get accountKeyEcdsaCurveInput(): string | undefined;
    private _accountKeyPem?;
    get accountKeyPem(): string;
    set accountKeyPem(value: string);
    resetAccountKeyPem(): void;
    get accountKeyPemInput(): string | undefined;
    private _accountKeyRsaBits?;
    get accountKeyRsaBits(): number;
    set accountKeyRsaBits(value: number);
    resetAccountKeyRsaBits(): void;
    get accountKeyRsaBitsInput(): number | undefined;
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    resetEmailAddress(): void;
    get emailAddressInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get registrationUrl(): string;
    private _externalAccountBinding;
    get externalAccountBinding(): RegistrationExternalAccountBindingOutputReference;
    putExternalAccountBinding(value: RegistrationExternalAccountBinding): void;
    resetExternalAccountBinding(): void;
    get externalAccountBindingInput(): RegistrationExternalAccountBinding | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
