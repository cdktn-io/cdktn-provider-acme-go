/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AcmeProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/3.2.1/docs#server_url AcmeProvider#server_url}
    */
    readonly serverUrl: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/3.2.1/docs#alias AcmeProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/vancluever/acme/3.2.1/docs acme}
*/
export declare class AcmeProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "acme";
    /**
    * Generates CDKTN code for importing a AcmeProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AcmeProvider to import
    * @param importFromId The id of the existing AcmeProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/vancluever/acme/3.2.1/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AcmeProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/vancluever/acme/3.2.1/docs acme} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AcmeProviderConfig
    */
    constructor(scope: Construct, id: string, config: AcmeProviderConfig);
    private _serverUrl?;
    get serverUrl(): string | undefined;
    set serverUrl(value: string | undefined);
    get serverUrlInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
