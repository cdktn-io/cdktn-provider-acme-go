/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#account_key_pem Certificate#account_key_pem}
    */
    readonly accountKeyPem: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#cert_timeout Certificate#cert_timeout}
    */
    readonly certTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#certificate_p12_password Certificate#certificate_p12_password}
    */
    readonly certificateP12Password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#certificate_request_pem Certificate#certificate_request_pem}
    */
    readonly certificateRequestPem?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#common_name Certificate#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#deactivate_authorizations Certificate#deactivate_authorizations}
    */
    readonly deactivateAuthorizations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#disable_complete_propagation Certificate#disable_complete_propagation}
    */
    readonly disableCompletePropagation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#id Certificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#key_type Certificate#key_type}
    */
    readonly keyType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#min_days_dynamic Certificate#min_days_dynamic}
    */
    readonly minDaysDynamic?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#min_days_remaining Certificate#min_days_remaining}
    */
    readonly minDaysRemaining?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#must_staple Certificate#must_staple}
    */
    readonly mustStaple?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#pre_check_delay Certificate#pre_check_delay}
    */
    readonly preCheckDelay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#preferred_chain Certificate#preferred_chain}
    */
    readonly preferredChain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#profile Certificate#profile}
    */
    readonly profile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#propagation_wait Certificate#propagation_wait}
    */
    readonly propagationWait?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#recursive_nameservers Certificate#recursive_nameservers}
    */
    readonly recursiveNameservers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#renewal_info_ignore_retry_after Certificate#renewal_info_ignore_retry_after}
    */
    readonly renewalInfoIgnoreRetryAfter?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#renewal_info_max_sleep Certificate#renewal_info_max_sleep}
    */
    readonly renewalInfoMaxSleep?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#revoke_certificate_on_destroy Certificate#revoke_certificate_on_destroy}
    */
    readonly revokeCertificateOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#revoke_certificate_reason Certificate#revoke_certificate_reason}
    */
    readonly revokeCertificateReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#subject_alternative_names Certificate#subject_alternative_names}
    */
    readonly subjectAlternativeNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#use_renewal_info Certificate#use_renewal_info}
    */
    readonly useRenewalInfo?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#validity_days Certificate#validity_days}
    */
    readonly validityDays?: number;
    /**
    * dns_challenge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#dns_challenge Certificate#dns_challenge}
    */
    readonly dnsChallenge?: CertificateDnsChallenge[] | cdktn.IResolvable;
    /**
    * http_challenge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#http_challenge Certificate#http_challenge}
    */
    readonly httpChallenge?: CertificateHttpChallenge;
    /**
    * http_memcached_challenge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#http_memcached_challenge Certificate#http_memcached_challenge}
    */
    readonly httpMemcachedChallenge?: CertificateHttpMemcachedChallenge;
    /**
    * http_s3_challenge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#http_s3_challenge Certificate#http_s3_challenge}
    */
    readonly httpS3Challenge?: CertificateHttpS3Challenge;
    /**
    * http_webroot_challenge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#http_webroot_challenge Certificate#http_webroot_challenge}
    */
    readonly httpWebrootChallenge?: CertificateHttpWebrootChallenge;
    /**
    * tls_challenge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#tls_challenge Certificate#tls_challenge}
    */
    readonly tlsChallenge?: CertificateTlsChallenge;
}
export interface CertificateDnsChallenge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#config Certificate#config}
    */
    readonly config?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#provider Certificate#provider}
    */
    readonly provider: string;
}
export declare function certificateDnsChallengeToTerraform(struct?: CertificateDnsChallenge | cdktn.IResolvable): any;
export declare function certificateDnsChallengeToHclTerraform(struct?: CertificateDnsChallenge | cdktn.IResolvable): any;
export declare class CertificateDnsChallengeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateDnsChallenge | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateDnsChallenge | cdktn.IResolvable | undefined);
    private _config?;
    get config(): {
        [key: string]: string;
    };
    set config(value: {
        [key: string]: string;
    });
    resetConfig(): void;
    get configInput(): {
        [key: string]: string;
    } | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
}
export declare class CertificateDnsChallengeList extends cdktn.ComplexList {
    internalValue?: CertificateDnsChallenge[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateDnsChallengeOutputReference;
}
export interface CertificateHttpChallenge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#port Certificate#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#proxy_header Certificate#proxy_header}
    */
    readonly proxyHeader?: string;
}
export declare function certificateHttpChallengeToTerraform(struct?: CertificateHttpChallengeOutputReference | CertificateHttpChallenge): any;
export declare function certificateHttpChallengeToHclTerraform(struct?: CertificateHttpChallengeOutputReference | CertificateHttpChallenge): any;
export declare class CertificateHttpChallengeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateHttpChallenge | undefined;
    set internalValue(value: CertificateHttpChallenge | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _proxyHeader?;
    get proxyHeader(): string;
    set proxyHeader(value: string);
    resetProxyHeader(): void;
    get proxyHeaderInput(): string | undefined;
}
export interface CertificateHttpMemcachedChallenge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#hosts Certificate#hosts}
    */
    readonly hosts: string[];
}
export declare function certificateHttpMemcachedChallengeToTerraform(struct?: CertificateHttpMemcachedChallengeOutputReference | CertificateHttpMemcachedChallenge): any;
export declare function certificateHttpMemcachedChallengeToHclTerraform(struct?: CertificateHttpMemcachedChallengeOutputReference | CertificateHttpMemcachedChallenge): any;
export declare class CertificateHttpMemcachedChallengeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateHttpMemcachedChallenge | undefined;
    set internalValue(value: CertificateHttpMemcachedChallenge | undefined);
    private _hosts?;
    get hosts(): string[];
    set hosts(value: string[]);
    get hostsInput(): string[] | undefined;
}
export interface CertificateHttpS3Challenge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#s3_bucket Certificate#s3_bucket}
    */
    readonly s3Bucket: string;
}
export declare function certificateHttpS3ChallengeToTerraform(struct?: CertificateHttpS3ChallengeOutputReference | CertificateHttpS3Challenge): any;
export declare function certificateHttpS3ChallengeToHclTerraform(struct?: CertificateHttpS3ChallengeOutputReference | CertificateHttpS3Challenge): any;
export declare class CertificateHttpS3ChallengeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateHttpS3Challenge | undefined;
    set internalValue(value: CertificateHttpS3Challenge | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    get s3BucketInput(): string | undefined;
}
export interface CertificateHttpWebrootChallenge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#directory Certificate#directory}
    */
    readonly directory: string;
}
export declare function certificateHttpWebrootChallengeToTerraform(struct?: CertificateHttpWebrootChallengeOutputReference | CertificateHttpWebrootChallenge): any;
export declare function certificateHttpWebrootChallengeToHclTerraform(struct?: CertificateHttpWebrootChallengeOutputReference | CertificateHttpWebrootChallenge): any;
export declare class CertificateHttpWebrootChallengeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateHttpWebrootChallenge | undefined;
    set internalValue(value: CertificateHttpWebrootChallenge | undefined);
    private _directory?;
    get directory(): string;
    set directory(value: string);
    get directoryInput(): string | undefined;
}
export interface CertificateTlsChallenge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#port Certificate#port}
    */
    readonly port?: number;
}
export declare function certificateTlsChallengeToTerraform(struct?: CertificateTlsChallengeOutputReference | CertificateTlsChallenge): any;
export declare function certificateTlsChallengeToHclTerraform(struct?: CertificateTlsChallengeOutputReference | CertificateTlsChallenge): any;
export declare class CertificateTlsChallengeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateTlsChallenge | undefined;
    set internalValue(value: CertificateTlsChallenge | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate acme_certificate}
*/
export declare class Certificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "acme_certificate";
    /**
    * Generates CDKTN code for importing a Certificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Certificate to import
    * @param importFromId The id of the existing Certificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Certificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/vancluever/acme/2.47.0/docs/resources/certificate acme_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificateConfig
    */
    constructor(scope: Construct, id: string, config: CertificateConfig);
    private _accountKeyPem?;
    get accountKeyPem(): string;
    set accountKeyPem(value: string);
    get accountKeyPemInput(): string | undefined;
    private _certTimeout?;
    get certTimeout(): number;
    set certTimeout(value: number);
    resetCertTimeout(): void;
    get certTimeoutInput(): number | undefined;
    get certificateDomain(): string;
    get certificateNotAfter(): string;
    get certificateNotBefore(): string;
    get certificateP12(): string;
    private _certificateP12Password?;
    get certificateP12Password(): string;
    set certificateP12Password(value: string);
    resetCertificateP12Password(): void;
    get certificateP12PasswordInput(): string | undefined;
    get certificatePem(): string;
    private _certificateRequestPem?;
    get certificateRequestPem(): string;
    set certificateRequestPem(value: string);
    resetCertificateRequestPem(): void;
    get certificateRequestPemInput(): string | undefined;
    get certificateSerial(): string;
    get certificateUrl(): string;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _deactivateAuthorizations?;
    get deactivateAuthorizations(): boolean | cdktn.IResolvable;
    set deactivateAuthorizations(value: boolean | cdktn.IResolvable);
    resetDeactivateAuthorizations(): void;
    get deactivateAuthorizationsInput(): boolean | cdktn.IResolvable | undefined;
    private _disableCompletePropagation?;
    get disableCompletePropagation(): boolean | cdktn.IResolvable;
    set disableCompletePropagation(value: boolean | cdktn.IResolvable);
    resetDisableCompletePropagation(): void;
    get disableCompletePropagationInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuerPem(): string;
    private _keyType?;
    get keyType(): string;
    set keyType(value: string);
    resetKeyType(): void;
    get keyTypeInput(): string | undefined;
    private _minDaysDynamic?;
    get minDaysDynamic(): boolean | cdktn.IResolvable;
    set minDaysDynamic(value: boolean | cdktn.IResolvable);
    resetMinDaysDynamic(): void;
    get minDaysDynamicInput(): boolean | cdktn.IResolvable | undefined;
    private _minDaysRemaining?;
    get minDaysRemaining(): number;
    set minDaysRemaining(value: number);
    resetMinDaysRemaining(): void;
    get minDaysRemainingInput(): number | undefined;
    private _mustStaple?;
    get mustStaple(): boolean | cdktn.IResolvable;
    set mustStaple(value: boolean | cdktn.IResolvable);
    resetMustStaple(): void;
    get mustStapleInput(): boolean | cdktn.IResolvable | undefined;
    private _preCheckDelay?;
    get preCheckDelay(): number;
    set preCheckDelay(value: number);
    resetPreCheckDelay(): void;
    get preCheckDelayInput(): number | undefined;
    private _preferredChain?;
    get preferredChain(): string;
    set preferredChain(value: string);
    resetPreferredChain(): void;
    get preferredChainInput(): string | undefined;
    get privateKeyPem(): string;
    private _profile?;
    get profile(): string;
    set profile(value: string);
    resetProfile(): void;
    get profileInput(): string | undefined;
    private _propagationWait?;
    get propagationWait(): number;
    set propagationWait(value: number);
    resetPropagationWait(): void;
    get propagationWaitInput(): number | undefined;
    private _recursiveNameservers?;
    get recursiveNameservers(): string[];
    set recursiveNameservers(value: string[]);
    resetRecursiveNameservers(): void;
    get recursiveNameserversInput(): string[] | undefined;
    get renewalInfoExplanationUrl(): string;
    private _renewalInfoIgnoreRetryAfter?;
    get renewalInfoIgnoreRetryAfter(): boolean | cdktn.IResolvable;
    set renewalInfoIgnoreRetryAfter(value: boolean | cdktn.IResolvable);
    resetRenewalInfoIgnoreRetryAfter(): void;
    get renewalInfoIgnoreRetryAfterInput(): boolean | cdktn.IResolvable | undefined;
    private _renewalInfoMaxSleep?;
    get renewalInfoMaxSleep(): number;
    set renewalInfoMaxSleep(value: number);
    resetRenewalInfoMaxSleep(): void;
    get renewalInfoMaxSleepInput(): number | undefined;
    get renewalInfoRetryAfter(): string;
    get renewalInfoWindowEnd(): string;
    get renewalInfoWindowSelected(): string;
    get renewalInfoWindowStart(): string;
    private _revokeCertificateOnDestroy?;
    get revokeCertificateOnDestroy(): boolean | cdktn.IResolvable;
    set revokeCertificateOnDestroy(value: boolean | cdktn.IResolvable);
    resetRevokeCertificateOnDestroy(): void;
    get revokeCertificateOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _revokeCertificateReason?;
    get revokeCertificateReason(): string;
    set revokeCertificateReason(value: string);
    resetRevokeCertificateReason(): void;
    get revokeCertificateReasonInput(): string | undefined;
    private _subjectAlternativeNames?;
    get subjectAlternativeNames(): string[];
    set subjectAlternativeNames(value: string[]);
    resetSubjectAlternativeNames(): void;
    get subjectAlternativeNamesInput(): string[] | undefined;
    private _useRenewalInfo?;
    get useRenewalInfo(): boolean | cdktn.IResolvable;
    set useRenewalInfo(value: boolean | cdktn.IResolvable);
    resetUseRenewalInfo(): void;
    get useRenewalInfoInput(): boolean | cdktn.IResolvable | undefined;
    private _validityDays?;
    get validityDays(): number;
    set validityDays(value: number);
    resetValidityDays(): void;
    get validityDaysInput(): number | undefined;
    private _dnsChallenge;
    get dnsChallenge(): CertificateDnsChallengeList;
    putDnsChallenge(value: CertificateDnsChallenge[] | cdktn.IResolvable): void;
    resetDnsChallenge(): void;
    get dnsChallengeInput(): cdktn.IResolvable | CertificateDnsChallenge[] | undefined;
    private _httpChallenge;
    get httpChallenge(): CertificateHttpChallengeOutputReference;
    putHttpChallenge(value: CertificateHttpChallenge): void;
    resetHttpChallenge(): void;
    get httpChallengeInput(): CertificateHttpChallenge | undefined;
    private _httpMemcachedChallenge;
    get httpMemcachedChallenge(): CertificateHttpMemcachedChallengeOutputReference;
    putHttpMemcachedChallenge(value: CertificateHttpMemcachedChallenge): void;
    resetHttpMemcachedChallenge(): void;
    get httpMemcachedChallengeInput(): CertificateHttpMemcachedChallenge | undefined;
    private _httpS3Challenge;
    get httpS3Challenge(): CertificateHttpS3ChallengeOutputReference;
    putHttpS3Challenge(value: CertificateHttpS3Challenge): void;
    resetHttpS3Challenge(): void;
    get httpS3ChallengeInput(): CertificateHttpS3Challenge | undefined;
    private _httpWebrootChallenge;
    get httpWebrootChallenge(): CertificateHttpWebrootChallengeOutputReference;
    putHttpWebrootChallenge(value: CertificateHttpWebrootChallenge): void;
    resetHttpWebrootChallenge(): void;
    get httpWebrootChallengeInput(): CertificateHttpWebrootChallenge | undefined;
    private _tlsChallenge;
    get tlsChallenge(): CertificateTlsChallengeOutputReference;
    putTlsChallenge(value: CertificateTlsChallenge): void;
    resetTlsChallenge(): void;
    get tlsChallengeInput(): CertificateTlsChallenge | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
